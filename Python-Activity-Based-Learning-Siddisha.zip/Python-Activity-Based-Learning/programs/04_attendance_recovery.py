# Attendance Recovery Computation

def attendance_percentage(attended, conducted):
    if conducted <= 0:
        raise ValueError("Conducted classes must be greater than zero.")
    if attended < 0 or attended > conducted:
        raise ValueError("Attended classes must be between 0 and conducted.")
    return attended / conducted * 100


def classes_to_recover(attended, conducted, target):
    if not 0 < target <= 100:
        raise ValueError("Target must be above 0 and at most 100.")
    extra = 0
    while (attended + extra) / (conducted + extra) * 100 < target:
        extra += 1
    return extra


def main():
    attended, conducted, target = 36, 50, 75
    current = attendance_percentage(attended, conducted)
    required = classes_to_recover(attended, conducted, target)
    scenario = attendance_percentage(attended + 5, conducted + 8)

    print("ATTENDANCE RECOVERY REPORT")
    print("-" * 42)
    print(f"Classes attended : {attended}")
    print(f"Classes conducted: {conducted}")
    print(f"Current attendance: {current:.2f}%")
    print(f"Target attendance : {target:.2f}%")
    print(f"Extra consecutive classes to attend: {required}")
    print(f"If 5 of next 8 classes are attended: {scenario:.2f}%")


if __name__ == "__main__":
    main()
