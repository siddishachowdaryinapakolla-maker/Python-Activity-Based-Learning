# Employee Payroll and Deduction Analysis

def progressive_deduction(gross):
    first = min(gross, 20000) * 0.05
    second = min(max(gross - 20000, 0), 20000) * 0.10
    third = max(gross - 40000, 0) * 0.15
    return first + second + third


def calculate_payroll(name, basic, overtime_hours, incentive):
    if basic < 0 or overtime_hours < 0 or incentive < 0:
        raise ValueError("Salary inputs cannot be negative.")

    hra = basic * 0.20
    travel = basic * 0.10
    hourly_rate = basic / 160
    overtime_pay = overtime_hours * hourly_rate * 1.5
    gross = basic + hra + travel + overtime_pay + incentive
    deduction = progressive_deduction(gross)
    net = gross - deduction

    # Return values as a tuple; unpacking is used in main().
    return (name, basic, hra, travel, overtime_pay, incentive,
            gross, deduction, net)


def main():
    employee = calculate_payroll("Asha", 30000, 5, 2000)
    name, basic, hra, travel, overtime, incentive, gross, deduction, net = employee
    print("EMPLOYEE SALARY STATEMENT")
    print("-" * 42)
    print("Employee:", name)
    print(f"{'Basic Pay':20}: Rs. {basic:,.2f}")
    print(f"{'HRA':20}: Rs. {hra:,.2f}")
    print(f"{'Travel Allowance':20}: Rs. {travel:,.2f}")
    print(f"{'Overtime Pay':20}: Rs. {overtime:,.2f}")
    print(f"{'Incentive':20}: Rs. {incentive:,.2f}")
    print(f"{'Gross Salary':20}: Rs. {gross:,.2f}")
    print(f"{'Deduction':20}: Rs. {deduction:,.2f}")
    print(f"{'Net Salary':20}: Rs. {net:,.2f}")


if __name__ == "__main__":
    main()
