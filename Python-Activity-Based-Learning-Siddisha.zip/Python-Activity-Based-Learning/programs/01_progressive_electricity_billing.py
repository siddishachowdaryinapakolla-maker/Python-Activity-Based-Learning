# Progressive Electricity Billing
# Sample tariff for academic practice only.

def calculate_energy_charge(units):
    if units < 0:
        raise ValueError("Units cannot be negative.")

    if units <= 100:
        return units * 1.50
    elif units <= 200:
        return 100 * 1.50 + (units - 100) * 2.50
    else:
        return 100 * 1.50 + 100 * 2.50 + (units - 200) * 4.00


def calculate_bill(units):
    fixed_charge = 50.0
    energy_charge = calculate_energy_charge(units)
    subtotal = energy_charge + fixed_charge
    rebate = subtotal * 0.05 if units <= 100 else 0.0
    return subtotal - rebate


def main():
    monthly_units = [80, 150, 250, 120]
    bills = []

    print("PROGRESSIVE ELECTRICITY BILL")
    print("-" * 48)
    for month_number, units in enumerate(monthly_units, start=1):
        bill = calculate_bill(units)
        bills.append(bill)
        print(f"Month {month_number}: {units:3} units | Bill: Rs. {bill:.2f}")

    print("\nMONTH-TO-MONTH ANALYSIS")
    for index in range(1, len(bills)):
        increase = bills[index] - bills[index - 1]
        percentage = (increase / bills[index - 1]) * 100 if bills[index - 1] else 0
        status = "UNUSUAL INCREASE" if percentage > 30 else "Normal change"
        print(f"Month {index + 1}: {percentage:.2f}% | {status}")


if __name__ == "__main__":
    main()
