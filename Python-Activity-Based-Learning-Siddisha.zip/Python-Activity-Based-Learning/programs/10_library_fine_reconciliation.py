# Library Borrowing and Fine Reconciliation

def reconcile_library(records, allowed_days=14, fine_per_day=2):
    if allowed_days < 0 or fine_per_day < 0:
        raise ValueError("Policy values cannot be negative.")

    total_fine = 0
    returned_count = 0
    borrowed_count = 0
    overdue_records = []

    for book_id, days_borrowed, returned in records:
        if days_borrowed < 0:
            raise ValueError("Borrowing days cannot be negative.")

        overdue_days = max(days_borrowed - allowed_days, 0)
        fine = overdue_days * fine_per_day
        total_fine += fine

        if returned:
            returned_count += 1
        else:
            borrowed_count += 1

        if overdue_days > 0:
            overdue_records.append((book_id, overdue_days, fine, returned))

    return overdue_records, total_fine, returned_count, borrowed_count


def main():
    records = [
        ("BK101", 10, True),
        ("BK102", 17, True),
        ("BK103", 22, False),
        ("BK104", 14, False),
        ("BK105", 16, True)
    ]
    overdue, total_fine, returned, borrowed = reconcile_library(records)

    print("LIBRARY FINE RECONCILIATION")
    print("-" * 60)
    print("Overdue records:")
    for book_id, days, fine, is_returned in overdue:
        status = "Returned" if is_returned else "Not returned"
        print(f"{book_id}: {days} overdue days | Fine Rs.{fine:.2f} | {status}")
    print("-" * 60)
    print(f"Total fine due: Rs. {total_fine:.2f}")
    print(f"Returned records: {returned}")
    print(f"Currently borrowed records: {borrowed}")


if __name__ == "__main__":
    main()
