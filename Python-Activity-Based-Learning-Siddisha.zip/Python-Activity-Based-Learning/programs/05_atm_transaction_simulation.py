# ATM Transaction Sequence Simulation
# This program is a simulation only; it does not access a real bank account.

def process_transactions(opening_balance, transactions, daily_limit):
    if opening_balance < 0 or daily_limit < 0:
        raise ValueError("Opening balance and limit cannot be negative.")

    balance = opening_balance
    withdrawn_today = 0.0
    log = []

    for transaction_type, amount in transactions:
        status = "REJECTED"
        if amount <= 0:
            reason = "Amount must be positive"
        elif transaction_type == "DEPOSIT":
            balance += amount
            status, reason = "ACCEPTED", "Deposit successful"
        elif transaction_type == "WITHDRAW":
            if amount > balance:
                reason = "Insufficient balance"
            elif withdrawn_today + amount > daily_limit:
                reason = "Daily withdrawal limit exceeded"
            else:
                balance -= amount
                withdrawn_today += amount
                status, reason = "ACCEPTED", "Withdrawal successful"
        else:
            reason = "Unknown transaction type"

        log.append((transaction_type, amount, status, reason, balance))

    return log, balance


def main():
    transactions = [
        ("DEPOSIT", 1000),
        ("WITHDRAW", 2000),
        ("WITHDRAW", 1500),
        ("WITHDRAW", 500),
        ("DEPOSIT", 0)
    ]
    log, final_balance = process_transactions(5000, transactions, 3000)

    print("ATM TRANSACTION REPORT")
    print("-" * 68)
    for number, (kind, amount, status, reason, balance) in enumerate(log, start=1):
        print(f"{number}. {kind:8} Rs.{amount:8.2f} | {status:8} | {reason}")
        print(f"   Balance after transaction: Rs. {balance:.2f}")
    accepted = sum(1 for item in log if item[2] == "ACCEPTED")
    rejected = len(log) - accepted
    print("-" * 68)
    print(f"Accepted: {accepted} | Rejected: {rejected}")
    print(f"Final balance: Rs. {final_balance:.2f}")


if __name__ == "__main__":
    main()
