# Nested Loop Calendar Generator

def generate_calendar(month_name, number_of_days, start_weekday):
    if not 28 <= number_of_days <= 31:
        raise ValueError("This program accepts month lengths from 28 to 31 days.")
    if not 0 <= start_weekday <= 6:
        raise ValueError("Starting weekday must be 0 (Sunday) to 6 (Saturday).")

    print(f"\n{month_name.upper()}")
    print("Sun Mon Tue Wed Thu Fri Sat")
    date = 1

    for week in range(6):
        row = ""
        for day in range(7):
            position = week * 7 + day
            if position < start_weekday or date > number_of_days:
                row += "    "
            else:
                row += f"{date:3} "
                date += 1
        print(row.rstrip())
        if date > number_of_days:
            break


def main():
    generate_calendar("October 2026", 31, 4)  # 0=Sunday; 4=Thursday


if __name__ == "__main__":
    main()
