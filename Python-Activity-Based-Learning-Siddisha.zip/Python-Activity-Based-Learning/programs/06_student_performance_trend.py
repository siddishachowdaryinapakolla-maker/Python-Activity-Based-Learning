# Student Performance Trend Analysis

def analyze_performance(subjects, marks):
    if not marks or any(len(row) != len(subjects) for row in marks):
        raise ValueError("Marks matrix must be non-empty and match the subject count.")
    for row in marks:
        for mark in row:
            if mark < 0 or mark > 100:
                raise ValueError("Every mark must be between 0 and 100.")

    averages = []
    changes = []
    for column in range(len(subjects)):
        subject_scores = [row[column] for row in marks]
        averages.append(sum(subject_scores) / len(subject_scores))
        changes.append(subject_scores[-1] - subject_scores[0])

    all_marks = [mark for row in marks for mark in row]
    overall = sum(all_marks) / len(all_marks)

    if overall >= 75:
        classification = "Excellent"
    elif overall >= 60:
        classification = "Good"
    elif overall >= 40:
        classification = "Average"
    else:
        classification = "Needs Improvement"

    weakest_index = averages.index(min(averages))
    return averages, changes, overall, classification, subjects[weakest_index]


def main():
    subjects = ["Python", "Maths", "Physics", "English"]
    marks = [
        [65, 70, 60, 75],
        [72, 68, 64, 78],
        [80, 75, 66, 82]
    ]
    averages, changes, overall, classification, weakest = analyze_performance(subjects, marks)

    print("STUDENT PERFORMANCE TREND")
    print("-" * 58)
    print(f"{'Subject':12} {'Average':>10} {'Change (Exam 1 to 3)':>22}")
    for index, subject in enumerate(subjects):
        print(f"{subject:12} {averages[index]:10.2f} {changes[index]:22.2f}")
    print("-" * 58)
    print(f"Overall average : {overall:.2f}")
    print(f"Classification  : {classification}")
    print(f"Weakest subject : {weakest}")


if __name__ == "__main__":
    main()
