# Retail Billing with Multiple Discount Rules

TAX_RATES = {"food": 0.05, "stationery": 0.12, "other": 0.18}


def create_invoice(products):
    subtotal = 0.0
    tax_total = 0.0
    lines = []

    for name, category, price, quantity in products:
        if price < 0 or quantity <= 0:
            raise ValueError("Price must be non-negative and quantity must be positive.")
        if category not in TAX_RATES:
            raise ValueError(f"Unknown category: {category}")

        amount = price * quantity
        tax = amount * TAX_RATES[category]
        subtotal += amount
        tax_total += tax
        lines.append((name, quantity, amount, tax))

    discount = min(subtotal * 0.10, 500.0) if subtotal >= 2000 else 0.0
    final_amount = subtotal - discount + tax_total
    return lines, subtotal, tax_total, discount, final_amount


def main():
    products = [
        ("Notebook", "stationery", 80, 5),
        ("Rice Bag", "food", 650, 2),
        ("Water Bottle", "other", 250, 2)
    ]
    lines, subtotal, tax, discount, total = create_invoice(products)

    print("RETAIL INVOICE")
    print("-" * 58)
    print(f"{'Product':18} {'Qty':>4} {'Amount':>12} {'Tax':>10}")
    for name, quantity, amount, item_tax in lines:
        print(f"{name:18} {quantity:>4} {amount:>12.2f} {item_tax:>10.2f}")
    print("-" * 58)
    print(f"Subtotal       : Rs. {subtotal:.2f}")
    print(f"Tax            : Rs. {tax:.2f}")
    print(f"Discount       : Rs. {discount:.2f}")
    print(f"FINAL AMOUNT   : Rs. {total:.2f}")


if __name__ == "__main__":
    main()
