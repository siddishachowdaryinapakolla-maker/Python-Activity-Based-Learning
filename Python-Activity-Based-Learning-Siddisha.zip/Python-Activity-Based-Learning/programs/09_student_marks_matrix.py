# Student Marks Matrix Analysis

def analyze_marks(student_names, subjects, marks, low_average_limit=50):
    if not marks or len(marks) != len(student_names):
        raise ValueError("One marks row is required for each student.")
    if any(len(row) != len(subjects) for row in marks):
        raise ValueError("Each student must have one mark per subject.")
    for row in marks:
        for mark in row:
            if not isinstance(mark, int) or not 0 <= mark <= 100:
                raise ValueError("Marks must be integers from 0 to 100.")

    totals = [sum(row) for row in marks]
    averages = [total / len(subjects) for total in totals]
    subject_averages = []

    for column in range(len(subjects)):
        total = 0
        for row in marks:
            total += row[column]
        subject_averages.append(total / len(marks))

    highest_total = max(totals)
    toppers = [
        student_names[index]
        for index in range(len(student_names))
        if totals[index] == highest_total
    ]
    low_subjects = [
        subjects[index]
        for index in range(len(subjects))
        if subject_averages[index] < low_average_limit
    ]
    return totals, averages, subject_averages, toppers, low_subjects


def main():
    students = ["Asha", "Bharat", "Charan", "Divya"]
    subjects = ["Python", "Maths", "Physics"]
    marks = [
        [88, 92, 84],
        [76, 81, 79],
        [95, 90, 91],
        [65, 72, 68]
    ]
    totals, averages, subject_avgs, toppers, low_subjects = analyze_marks(
        students, subjects, marks
    )

    print("STUDENT MARKS MATRIX REPORT")
    print("-" * 60)
    print(f"{'Student':12} {'Total':>8} {'Average':>10}")
    for index, name in enumerate(students):
        print(f"{name:12} {totals[index]:8} {averages[index]:10.2f}")
    print("\nSubject averages:")
    for index, subject in enumerate(subjects):
        print(f"{subject:12}: {subject_avgs[index]:.2f}")
    print("Topper(s):", ", ".join(toppers))
    print("Subjects below average threshold:", low_subjects or "None")


if __name__ == "__main__":
    main()
