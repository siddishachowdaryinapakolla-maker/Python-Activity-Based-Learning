# Repeated Transaction Detection

def find_suspicious_transactions(transactions, threshold):
    if threshold < 0:
        raise ValueError("Threshold cannot be negative.")

    seen_ids = []
    suspicious = []

    for transaction_id, amount in transactions:
        if amount < 0:
            raise ValueError("Transaction amount cannot be negative.")

        reasons = []
        if transaction_id in seen_ids:
            reasons.append("Duplicate transaction ID")
        else:
            seen_ids.append(transaction_id)

        if amount > threshold:
            reasons.append("Amount exceeds review threshold")

        if reasons:
            suspicious.append((transaction_id, amount, reasons))

    return suspicious


def main():
    transactions = [
        ("TX101", 500),
        ("TX102", 12500),
        ("TX101", 700),
        ("TX103", 2500),
        ("TX104", 15000)
    ]
    suspicious = find_suspicious_transactions(transactions, 10000)

    print("TRANSACTION REVIEW REPORT")
    print("-" * 58)
    if not suspicious:
        print("No entries flagged for review.")
    else:
        for transaction_id, amount, reasons in suspicious:
            print(f"{transaction_id} | Rs. {amount:.2f}")
            for reason in reasons:
                print("  -", reason)
    print("-" * 58)
    print("Flagged entries:", len(suspicious))
    print("Note: A flag indicates review is needed, not proof of fraud.")


if __name__ == "__main__":
    main()
