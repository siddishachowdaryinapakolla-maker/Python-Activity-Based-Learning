# Case Study 4: Attendance Recovery Computation

## 1. Problem Statement
Calculate current attendance percentage and find the minimum number of consecutive classes a student must attend to reach a required eligibility percentage.

## 2. Objectives
- Calculate attendance percentage from attended and conducted classes.
- Use a loop to determine the minimum future classes needed.
- Compare different future attendance scenarios.

## 3. Assumptions
- Attended classes cannot exceed conducted classes.
- The target attendance is 75%.
- Future classes in the recovery calculation are all attended.
- A separate scenario reports the percentage if the student attends 5 out of the next 8 classes.

## 4. Algorithm
1. Read attended and conducted class counts.
2. Validate counts.
3. Calculate current attendance percentage.
4. Use a while loop to add attended future classes until target percentage is reached.
5. Calculate a separate 5-of-8 scenario.
6. Display results.

## 5. Flowchart
See `../flowcharts/04_flowchart.png`.

## 6. Pseudocode
```text
START
READ attended, conducted
VALIDATE 0 <= attended <= conducted and conducted > 0
CURRENT = attended / conducted * 100
SET extra = 0
WHILE (attended + extra) / (conducted + extra) < target:
  INCREMENT extra
SCENARIO = (attended + 5) / (conducted + 8) * 100
DISPLAY current, extra, scenario
STOP
```

## 7. Python Source Code
The executable source file is:
`../programs/04_attendance_recovery.py`

## 8. Test Cases
| Test input / condition | Expected result |
|---|---|
| 36 attended / 50 conducted | 72%; 6 consecutive attended classes to reach 75% |
| 30 / 40 | 75%; 0 extra classes |
| Attended 51 / conducted 50 | Rejected |

The program's sample execution is included in `../test_results/` and its screenshot is in `../output_screenshots/`.

## 9. Output Screenshot
See `../output_screenshots/04_output.png`.

## 10. Conclusion
The program demonstrates the selected Python concepts and produces a result based on the stated sample policy and assumptions. The functions validate important inputs and separate calculations from display logic, making the solution easier to test and understand.
