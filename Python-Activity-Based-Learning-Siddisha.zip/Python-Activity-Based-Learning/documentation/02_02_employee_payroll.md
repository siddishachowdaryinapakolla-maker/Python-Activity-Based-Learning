# Case Study 2: Employee Payroll and Deduction Analysis

## 1. Problem Statement
Calculate employee gross salary from basic pay, allowances, overtime and incentives. Apply progressive deductions and print a formatted salary statement.

## 2. Objectives
- Calculate allowances and overtime pay.
- Find gross salary and progressive deduction.
- Display net salary in a clear salary statement.
- Return calculated values as a tuple and unpack them for display.

## 3. Assumptions
- HRA is 20% of basic pay and travel allowance is 10% of basic pay.
- Overtime is paid at 1.5 times the hourly basic rate; a month has 160 standard working hours.
- Deduction is 5% on the first ₹20,000, 10% on the next ₹20,000, and 15% above ₹40,000 of gross salary.
- These are sample classroom rules, not actual tax or payroll advice.

## 4. Algorithm
1. Read employee details and salary inputs.
2. Validate that numeric inputs are non-negative.
3. Calculate HRA, travel allowance and overtime pay.
4. Add basic pay, allowances, overtime and incentive to get gross salary.
5. Calculate deduction progressively.
6. Subtract deduction from gross salary and print statement.

## 5. Flowchart
See `../flowcharts/02_flowchart.png`.

## 6. Pseudocode
```text
START
READ employee name, basic pay, overtime hours, incentive
VALIDATE all numeric inputs are non-negative
HRA = 20% of basic; TRAVEL = 10% of basic
HOURLY RATE = basic / 160
OVERTIME PAY = hours * hourly rate * 1.5
GROSS = basic + HRA + TRAVEL + overtime + incentive
CALCULATE progressive deduction
NET = GROSS - deduction
DISPLAY salary statement
STOP
```

## 7. Python Source Code
The executable source file is:
`../programs/02_employee_payroll.py`

## 8. Test Cases
| Test input / condition | Expected result |
|---|---|
| Basic ₹20,000; 0 OT; ₹0 incentive | Gross ₹26,000; deduction ₹1,300; net ₹24,700 |
| Basic ₹30,000; 5 OT; ₹2,000 incentive | Gross ₹42,406.25; deduction ₹3,360.94; net ₹39,045.31 |
| Negative basic pay | Rejected with ValueError |

The program's sample execution is included in `../test_results/` and its screenshot is in `../output_screenshots/`.

## 9. Output Screenshot
See `../output_screenshots/02_output.png`.

## 10. Conclusion
The program demonstrates the selected Python concepts and produces a result based on the stated sample policy and assumptions. The functions validate important inputs and separate calculations from display logic, making the solution easier to test and understand.
