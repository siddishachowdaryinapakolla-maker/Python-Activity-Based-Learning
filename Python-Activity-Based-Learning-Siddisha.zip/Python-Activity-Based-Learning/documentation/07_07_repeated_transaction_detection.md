# Case Study 7: Repeated Transaction Detection

## 1. Problem Statement
Process transaction identifiers and amounts, detect duplicate identifiers, flag amounts above a threshold, and generate a list of suspicious entries.

## 2. Objectives
- Use lists and tuples to store transaction records.
- Detect repeated identifiers using list operations.
- Flag large transaction amounts and report suspicious records.

## 3. Assumptions
- A transaction record is a tuple of identifier and amount.
- Identifiers should be unique.
- A transaction amount greater than ₹10,000 is flagged for review.
- A duplicate ID is flagged even if its amount is different; no claim of fraud is made.

## 4. Algorithm
1. Store transaction records in a list of tuples.
2. Create a list to track identifiers already seen.
3. For each record, check whether the identifier has appeared before.
4. Check whether the amount exceeds the review threshold.
5. Add reasons to a suspicious-record list.
6. Display all flagged records and their reasons.

## 5. Flowchart
See `../flowcharts/07_flowchart.png`.

## 6. Pseudocode
```text
START
STORE transactions as tuples (id, amount)
SET seen_ids = empty list; suspicious = empty list
FOR each transaction:
  SET reasons = empty list
  IF id in seen_ids: ADD duplicate reason
  ELSE ADD id to seen_ids
  IF amount > threshold: ADD high amount reason
  IF reasons is not empty: STORE transaction and reasons
DISPLAY suspicious list
STOP
```

## 7. Python Source Code
The executable source file is:
`../programs/07_repeated_transaction_detection.py`

## 8. Test Cases
| Test input / condition | Expected result |
|---|---|
| ID A01 appears twice | Both repeated occurrence is flagged |
| Amount ₹12,000 | Flagged as above threshold |
| Unique ID and ₹500 | Not flagged |
| Negative amount | Rejected |

The program's sample execution is included in `../test_results/` and its screenshot is in `../output_screenshots/`.

## 9. Output Screenshot
See `../output_screenshots/07_output.png`.

## 10. Conclusion
The program demonstrates the selected Python concepts and produces a result based on the stated sample policy and assumptions. The functions validate important inputs and separate calculations from display logic, making the solution easier to test and understand.
