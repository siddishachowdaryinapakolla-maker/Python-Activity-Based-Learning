# Case Study 8: Nested Loop Calendar Generator

## 1. Problem Statement
Generate a formatted monthly calendar using the number of days in a month and the weekday of the first day, aligning dates correctly into weeks.

## 2. Objectives
- Use nested loops to generate calendar rows and columns.
- Validate the month length and starting weekday.
- Display a correctly aligned monthly calendar.

## 3. Assumptions
- The first weekday is entered as 0 for Sunday through 6 for Saturday.
- The caller supplies the correct number of days for the chosen month.
- Leap-year calculation is outside this case study; the day count is supplied.
- A week contains seven days.

## 4. Algorithm
1. Read month name, number of days and starting weekday.
2. Validate day count from 28 to 31 and weekday from 0 to 6.
3. Print weekday headings.
4. Use nested loops to print six possible calendar rows and seven columns.
5. Print a date only when its calculated position is within the month.

## 5. Flowchart
See `../flowcharts/08_flowchart.png`.

## 6. Pseudocode
```text
START
READ month_name, number_of_days, start_weekday
VALIDATE 28 <= number_of_days <= 31 and 0 <= start_weekday <= 6
PRINT month heading and weekday names
SET date = 1
FOR each of 6 rows:
  FOR each of 7 columns:
    IF first position: account for start_weekday offset
    IF position contains a valid date: PRINT date; INCREMENT date
    ELSE PRINT blank space
STOP when all dates are printed
STOP
```

## 7. Python Source Code
The executable source file is:
`../programs/08_calendar_generator.py`

## 8. Test Cases
| Test input / condition | Expected result |
|---|---|
| 31 days; starts on Sunday (0) | Date 1 appears under Sunday; date 31 appears |
| 30 days; starts on Wednesday (3) | First three cells blank |
| Starting weekday 7 | Rejected |
| Day count 32 | Rejected |

The program's sample execution is included in `../test_results/` and its screenshot is in `../output_screenshots/`.

## 9. Output Screenshot
See `../output_screenshots/08_output.png`.

## 10. Conclusion
The program demonstrates the selected Python concepts and produces a result based on the stated sample policy and assumptions. The functions validate important inputs and separate calculations from display logic, making the solution easier to test and understand.
