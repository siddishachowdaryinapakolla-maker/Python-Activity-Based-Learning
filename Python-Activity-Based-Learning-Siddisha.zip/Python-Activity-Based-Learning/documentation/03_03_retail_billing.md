# Case Study 3: Retail Billing with Multiple Discount Rules

## 1. Problem Statement
Generate an itemized retail invoice for several products. Apply category-specific tax, a threshold discount and a maximum discount limit.

## 2. Objectives
- Calculate line totals for multiple products and quantities.
- Apply category-based tax rates.
- Apply a threshold discount without exceeding the maximum concession.

## 3. Assumptions
- Each product record contains name, category, unit price and quantity.
- Food tax is 5%; stationery tax is 12%; other items tax is 18%.
- A 10% discount applies when the pre-tax subtotal is at least ₹2,000.
- The discount is capped at ₹500 and is deducted from the pre-tax subtotal.

## 4. Algorithm
1. Create product records in a list of tuples.
2. Validate price and quantity.
3. Calculate each line amount and category tax.
4. Find subtotal and total tax.
5. Calculate discount when subtotal reaches ₹2,000, capped at ₹500.
6. Print itemized invoice and final amount.

## 5. Flowchart
See `../flowcharts/03_flowchart.png`.

## 6. Pseudocode
```text
START
STORE product tuples (name, category, price, quantity)
SET subtotal = 0, tax_total = 0
FOR each product tuple:
  VALIDATE price >= 0 and quantity > 0
  LINE = price * quantity; ADD LINE to subtotal
  SELECT tax rate using category
  ADD LINE * tax rate to tax_total
IF subtotal >= 2000: discount = MIN(subtotal * 10%, 500)
ELSE discount = 0
FINAL = subtotal - discount + tax_total
DISPLAY invoice
STOP
```

## 7. Python Source Code
The executable source file is:
`../programs/03_retail_billing.py`

## 8. Test Cases
| Test input / condition | Expected result |
|---|---|
| Subtotal ₹1,000 | No discount; discount ₹0 |
| Subtotal ₹2,000 | Discount ₹200 |
| Subtotal ₹8,000 | Discount capped at ₹500 |
| Quantity 0 | Rejected |

The program's sample execution is included in `../test_results/` and its screenshot is in `../output_screenshots/`.

## 9. Output Screenshot
See `../output_screenshots/03_output.png`.

## 10. Conclusion
The program demonstrates the selected Python concepts and produces a result based on the stated sample policy and assumptions. The functions validate important inputs and separate calculations from display logic, making the solution easier to test and understand.
