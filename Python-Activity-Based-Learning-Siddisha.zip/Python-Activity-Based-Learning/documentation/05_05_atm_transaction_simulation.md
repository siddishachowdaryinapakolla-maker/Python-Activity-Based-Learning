# Case Study 5: ATM Transaction Sequence Simulation

## 1. Problem Statement
Simulate a sequence of deposits and withdrawals, maintain the account balance, reject invalid transactions and withdrawals that exceed the available balance or daily limit, and summarize the transactions.

## 2. Objectives
- Process transactions using a loop and conditional statements.
- Validate transaction amounts.
- Maintain balance and summarize accepted and rejected transactions.

## 3. Assumptions
- The opening balance is ₹5,000.
- A withdrawal must be positive, must not exceed the available balance, and total accepted withdrawals per simulated day cannot exceed ₹3,000.
- Deposits must be positive.
- This is a classroom simulation and does not connect to a real bank.

## 4. Algorithm
1. Set opening balance and daily withdrawal total to zero.
2. Read the transaction sequence stored as tuples.
3. For each transaction, validate its type and amount.
4. Accept deposits and update balance.
5. For withdrawals, check balance and daily limit before updating.
6. Record transaction status and print final summary.

## 5. Flowchart
See `../flowcharts/05_flowchart.png`.

## 6. Pseudocode
```text
START
BALANCE = 5000; WITHDRAWN = 0
FOR each (type, amount) in transactions:
  IF amount <= 0: REJECT
  ELSE IF type is DEPOSIT: ADD amount to balance
  ELSE IF type is WITHDRAW:
    IF amount > balance OR WITHDRAWN + amount > 3000: REJECT
    ELSE SUBTRACT amount; ADD to WITHDRAWN
  ELSE REJECT unknown type
  RECORD result
DISPLAY transaction log and final balance
STOP
```

## 7. Python Source Code
The executable source file is:
`../programs/05_atm_transaction_simulation.py`

## 8. Test Cases
| Test input / condition | Expected result |
|---|---|
| Deposit ₹1,000 | Accepted; balance increases |
| Withdraw ₹2,000 from ₹5,000 | Accepted |
| Withdraw ₹3,500 in same day | Rejected if daily limit would be exceeded |
| Amount ₹0 | Rejected |

The program's sample execution is included in `../test_results/` and its screenshot is in `../output_screenshots/`.

## 9. Output Screenshot
See `../output_screenshots/05_output.png`.

## 10. Conclusion
The program demonstrates the selected Python concepts and produces a result based on the stated sample policy and assumptions. The functions validate important inputs and separate calculations from display logic, making the solution easier to test and understand.
