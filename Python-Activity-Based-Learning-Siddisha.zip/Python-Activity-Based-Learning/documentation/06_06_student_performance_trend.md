# Case Study 6: Student Performance Trend Analysis

## 1. Problem Statement
Compare subject scores across multiple examinations, calculate improvement or decline, identify the weakest subject, and classify overall performance using supplied thresholds.

## 2. Objectives
- Store marks in nested lists.
- Calculate subject averages and score changes.
- Identify the weakest subject and classify performance.

## 3. Assumptions
- Each row in the marks matrix represents one examination; each column represents a subject.
- All marks are between 0 and 100.
- Overall average of 75 or above is Excellent; 60 or above is Good; 40 or above is Average; otherwise Needs Improvement.
- The sample has three examinations and four subjects.

## 4. Algorithm
1. Create a nested list of examination marks and a subject-name list.
2. Validate matrix dimensions and mark ranges.
3. Calculate each subject average using column-wise totals.
4. Compare the last examination with the first examination.
5. Find the subject with the lowest average.
6. Calculate overall average and assign classification.

## 5. Flowchart
See `../flowcharts/06_flowchart.png`.

## 6. Pseudocode
```text
START
STORE subject names and marks matrix
VALIDATE every mark is between 0 and 100
FOR each subject column:
  CALCULATE average across examinations
  CHANGE = last mark - first mark
FIND subject with minimum average
CALCULATE overall average
IF average >= 75: Excellent; ELSE IF >= 60: Good; ELSE IF >= 40: Average; ELSE Needs Improvement
DISPLAY analysis
STOP
```

## 7. Python Source Code
The executable source file is:
`../programs/06_student_performance_trend.py`

## 8. Test Cases
| Test input / condition | Expected result |
|---|---|
| All marks 80 | Average 80; Excellent |
| Marks average 65 | Good |
| Any mark 105 | Rejected |
| Subject scores 50, 60, 70 | Change +20 |

The program's sample execution is included in `../test_results/` and its screenshot is in `../output_screenshots/`.

## 9. Output Screenshot
See `../output_screenshots/06_output.png`.

## 10. Conclusion
The program demonstrates the selected Python concepts and produces a result based on the stated sample policy and assumptions. The functions validate important inputs and separate calculations from display logic, making the solution easier to test and understand.
