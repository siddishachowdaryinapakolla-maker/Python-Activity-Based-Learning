# Case Study 1: Progressive Electricity Billing

## 1. Problem Statement
Calculate a household electricity bill using progressive consumption slabs, a fixed charge, and a rebate. Also compare bills for several months and flag an unusual increase.

## 2. Objectives
- Calculate energy charges slab by slab.
- Add the fixed charge and apply the stated rebate rule.
- Compare monthly bills and identify a rise greater than the specified threshold.

## 3. Assumptions
- The tariff is a sample academic tariff, not an official electricity-board tariff.
- Slabs are: first 100 units at ₹1.50/unit, next 100 at ₹2.50/unit, and units above 200 at ₹4.00/unit.
- A fixed charge of ₹50 is added; a 5% rebate applies when consumption is at most 100 units.
- An increase greater than 30% over the previous month is unusual.

## 4. Algorithm
1. Read monthly unit readings.
2. Reject negative consumption.
3. Calculate slab-wise energy charges.
4. Add fixed charge and apply eligible rebate.
5. Store each bill in a list.
6. Compare each month with the previous month and report increases above 30%.

## 5. Flowchart
See `../flowcharts/01_flowchart.png`.

## 6. Pseudocode
```text
START
SET tariff rates, fixed charge, rebate and threshold
FOR each month:
  READ units; VALIDATE units >= 0
  CALCULATE slab charges using conditions
  ADD fixed charge; APPLY rebate if eligible
  STORE bill
FOR each consecutive pair of bills:
  CALCULATE percentage change and flag unusual rise
DISPLAY bills and alerts
STOP
```

## 7. Python Source Code
The executable source file is:
`../programs/01_progressive_electricity_billing.py`

## 8. Test Cases
| Test input / condition | Expected result |
|---|---|
| 0 units | ₹50.00 |
| 80 units | ₹161.50 after 5% rebate |
| 150 units | ₹325.00 |
| 250 units | ₹650.00 |

The program's sample execution is included in `../test_results/` and its screenshot is in `../output_screenshots/`.

## 9. Output Screenshot
See `../output_screenshots/01_output.png`.

## 10. Conclusion
The program demonstrates the selected Python concepts and produces a result based on the stated sample policy and assumptions. The functions validate important inputs and separate calculations from display logic, making the solution easier to test and understand.
