# Case Study 9: Student Marks Matrix Analysis

## 1. Problem Statement
Analyze a matrix of student marks across subjects, calculate each student's total and average, calculate subject averages, identify the class topper, and find subjects with low average performance.

## 2. Objectives
- Represent marks using a nested list.
- Calculate row-wise and column-wise statistics.
- Identify the top performer and subjects below a threshold.

## 3. Assumptions
- Each row represents one student and each column represents one subject.
- Marks are integers from 0 to 100.
- The low subject-average threshold is 50.
- If multiple students share the highest total, all are reported as toppers.

## 4. Algorithm
1. Store student names, subject names and marks matrix.
2. Validate matrix dimensions and marks.
3. Calculate each student's total and average.
4. Calculate each subject's average.
5. Find the highest total and list all students with that total.
6. Identify subjects whose average is below 50.

## 5. Flowchart
See `../flowcharts/09_flowchart.png`.

## 6. Pseudocode
```text
START
STORE student names, subject names and marks matrix
VALIDATE matrix dimensions and marks range 0..100
FOR each student row: CALCULATE total and average
FOR each subject column: CALCULATE average
FIND maximum student total
LIST every student with maximum total
LIST subjects with average < 50
DISPLAY report
STOP
```

## 7. Python Source Code
The executable source file is:
`../programs/09_student_marks_matrix.py`

## 8. Test Cases
| Test input / condition | Expected result |
|---|---|
| Student marks 80, 90, 70 | Total 240; average 80 |
| Two students have equal top total | Both shown as toppers |
| Mark 101 | Rejected |
| Subject average 45 | Subject flagged low |

The program's sample execution is included in `../test_results/` and its screenshot is in `../output_screenshots/`.

## 9. Output Screenshot
See `../output_screenshots/09_output.png`.

## 10. Conclusion
The program demonstrates the selected Python concepts and produces a result based on the stated sample policy and assumptions. The functions validate important inputs and separate calculations from display logic, making the solution easier to test and understand.
