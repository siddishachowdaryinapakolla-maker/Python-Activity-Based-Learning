# Case Study 10: Library Borrowing and Fine Reconciliation

## 1. Problem Statement
Analyze library borrowing records stored as tuples, calculate overdue fines, identify overdue books, and reconcile returned and currently borrowed books.

## 2. Objectives
- Store borrowing records as tuples.
- Calculate overdue days and fines using conditional statements.
- Count available and borrowed copies.

## 3. Assumptions
- Each record is (book_id, days_borrowed, returned).
- The allowed borrowing period is 14 days.
- The fine is ₹2 for each day beyond 14 days.
- A returned book is available; a book not returned is currently borrowed.
- The example records represent one copy per record.

## 4. Algorithm
1. Store borrowing records as tuples.
2. Validate days borrowed are non-negative.
3. For each record, calculate overdue days beyond 14.
4. Calculate fine as overdue days multiplied by ₹2.
5. Count returned and not-returned records.
6. Display overdue details, total fine and availability summary.

## 5. Flowchart
See `../flowcharts/10_flowchart.png`.

## 6. Pseudocode
```text
START
STORE records as tuples (book_id, days_borrowed, returned)
SET total_fine = 0; returned_count = 0; borrowed_count = 0
FOR each record:
  VALIDATE days_borrowed >= 0
  overdue = MAX(days_borrowed - 14, 0)
  fine = overdue * 2
  ADD fine to total_fine
  IF returned: INCREMENT returned_count
  ELSE: INCREMENT borrowed_count
DISPLAY overdue records, total fine and counts
STOP
```

## 7. Python Source Code
The executable source file is:
`../programs/10_library_fine_reconciliation.py`

## 8. Test Cases
| Test input / condition | Expected result |
|---|---|
| Borrowed 10 days | Fine ₹0 |
| Borrowed 17 days | 3 overdue days; fine ₹6 |
| Borrowed 14 days | Fine ₹0 |
| Negative days | Rejected |

The program's sample execution is included in `../test_results/` and its screenshot is in `../output_screenshots/`.

## 9. Output Screenshot
See `../output_screenshots/10_output.png`.

## 10. Conclusion
The program demonstrates the selected Python concepts and produces a result based on the stated sample policy and assumptions. The functions validate important inputs and separate calculations from display logic, making the solution easier to test and understand.
