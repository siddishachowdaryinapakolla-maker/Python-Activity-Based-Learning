# Python Activity-Based Learning (ABL) — B.Tech I Year

This repository contains 10 Python case studies selected from the faculty-provided ABL case-study list.

## Student details
- Name: **Inapakolla Siddisha**
- Roll Number: **26001142**
- Branch: **CSM**
- Section: **5**
- Course: Python Programming

## Selected case studies
1. Progressive Electricity Billing
2. Employee Payroll and Deduction Analysis
3. Retail Billing with Multiple Discount Rules
4. Attendance Recovery Computation
5. ATM Transaction Sequence Simulation
6. Student Performance Trend Analysis
7. Repeated Transaction Detection
8. Nested Loop Calendar Generator
9. Student Marks Matrix Analysis
10. Library Borrowing and Fine Reconciliation

## Folder structure
- `programs/` — 10 executable Python source files.
- `documentation/` — problem statement, objectives, assumptions, algorithm, pseudocode, test cases and conclusion for each case.
- `flowcharts/` — flowchart image for each case.
- `output_screenshots/` — screenshots of sample program output.
- `test_results/` — text copies of sample outputs.
- `ABL_Consolidated_Report.pdf` — consolidated report containing the required documentation and code.

## Requirements
- Python 3.8 or later
- No third-party Python packages are required to run the programs.

## Run a program
Open a terminal in the project folder and run, for example:
```bash
python programs/01_progressive_electricity_billing.py
```
Run the other `.py` files in the same way.

## Important notes
- The tariff, deduction, discount, fine and eligibility values are sample assumptions for this academic exercise. They are not official real-world policies.
- The ATM program is only a simulation. It does not connect to a bank or handle real money.
- Review the assumptions and sample data with your faculty member before submission.
- Replace all student-detail placeholders before uploading to GitHub.
- The flowcharts are high-level visual summaries. The written algorithm and pseudocode specify the program logic in more detail.

## GitHub submission checklist
1. Sign in to your own GitHub account.
2. Create a repository named exactly `Python-Activity-Based-Learning`.
3. Upload the contents of this project folder (not just the ZIP file).
4. Check that all 10 `.py` files are present and readable.
5. Update the student details above.
6. Copy the repository URL and submit it to your Python faculty member / Lab Mentor.

## Academic integrity
Be prepared to explain the assumptions, logic, loops, conditions, lists, nested lists, tuples and calculations in each program. Run the programs yourself and make any changes requested by your faculty member.
