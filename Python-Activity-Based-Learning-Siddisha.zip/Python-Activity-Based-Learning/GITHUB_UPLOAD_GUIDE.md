# GitHub Upload Guide

1. Extract `Python-Activity-Based-Learning.zip` on your computer.
2. Open GitHub and sign in.
3. Click **New repository**.
4. Enter repository name: `Python-Activity-Based-Learning`.
5. Choose Public or Private according to your faculty's instructions.
6. Create the repository.
7. Click **Add file → Upload files**.
8. Open the extracted project folder, select its contents, and drag them into GitHub.
9. Wait for uploads to finish, add a commit message such as `Add Python ABL case studies`, and click **Commit changes**.
10. Open the repository page and copy its URL for submission.

Before submission, replace the student-detail placeholders in `README.md` and confirm your college's required visibility setting.
